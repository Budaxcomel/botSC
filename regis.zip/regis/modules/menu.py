from regis import *

@bot.on(events.NewMessage(pattern=r"(?:.regis|/regis|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" REGISTER IP ","daftar"),
Button.inline(" EXTEND IP ","extend")],
[Button.inline(" CHECK IP ","cekip"),
Button.inline(" DELETE IP ","deleteip")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' curl -sS https://github.com/Budaxcomel/permission/raw/main/ip | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")

		msg = f"""
**◇ ━━━━━━━━━━━━━━━━━━  ◇**
**◇    ☘️AUTOSCRIPT☘️◇**
**◇ ━━━━━━━━━━━━━━━━━━  ◇**
**» SENARAI HARGA :** 
🌸**RM5 30Days**
🍃**RM20 180Days**
🌻**RM30 1Year**
🐥**RM100 1IP LIFETIME**
**» Order :**@ownerimmanvpn
**◇ ━━━━━━━━━━━━━━━━━━  ◇**
**» Total Pelanggan :** `{ssh.strip()}`
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)

