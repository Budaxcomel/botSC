from regis import *

@bot.on(events.CallbackQuery(data=b'cekallip'))
async def cekallip(event):
    async def cekallip_(event):
        cmd = 'bash /root/regis/shell/bot-member-ip'.strip()  # Ganti dengan jalur lengkap ke 'bot-member-ip'
        try:
            x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
```
{z}
```
**Show All IP USER**
**» 🤖@ownerimmanvpn**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError as e:
            print(f"Error menjalankan perintah: {e}")
            print(f"Output: {e.output}")
            await event.respond(f"Error executing command: {e.output}")

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cekallip_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
