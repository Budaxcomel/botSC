from adminbot import *
import subprocess, asyncio
from telethon import Button, events
#CREATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
  async def create_ssh_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Password :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Date**",buttons=[
[Button.inline("• 7 Days •","7"),
Button.inline("• 15 Days •","15")],
[Button.inline("• 30 Days •","30"),
Button.inline("• 60 Days •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Create Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{ip}" | /etc/shell/1'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("ssh://(.*)",a)]
      print(b)
      ns = re.search("ssh://(.*?):", b[0]).group(1)
      pub = re.search("ssh://(.*?):", b[1]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**     ◇⟨ SSH OpenVPN Account ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Username     :** `{user}`
**» Password     :** `{pw}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» SSH UDP Account   :**
`{DOMAIN}:54-65535@{remark}:{pw}`
**» SSH WSS Account  :**
`{DOMAIN}:80@{remark}:{pw}`
**◇━━━━━━━━━━━━━━━━━━━━━◇** 
**» Limit Adress        :** `{ip} IP`
**» Host Domain       :** `{DOMAIN}`
**» Host NSDomain  :** `{ns}`
**» Pub Key               :** `{pub}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Port UDP Custom    :** `54-65535` 
**» Port SSL TLS/SNI    :** `443` 
**» Port WSS NTLS        :** `80, 8080, 8880`
**» Port WSS TLS/SNI   :** `443`
**» Port OVPN                :** `443, 1194, 2200`
**» Proxy Squid              :** `3128`
**» BadVPN UDP            :** `7100-7300`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» OpenVPN Config  :**
**https://{DOMAIN}:81/OpenVPN.zip**
**» Psiphon Config    :**
**https://{DOMAIN}:81/psiphon.txt**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account       :**
**https://{DOMAIN}:81/ssh-{user}.txt**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `{later}`
**» 🤖@ownerimmanvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_ssh_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

# TRIAL SSH
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
  async def trial_ssh_(event):
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    await event.edit("`Processing Create Triall Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "${ip}" | /etc/shell/6'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      b = [x.group() for x in re.finditer("ssh://(.*)",a)]
      print(b)
      ns = re.search("ssh://(.*?):", b[0]).group(1)
      pub = re.search("ssh://(.*?):", b[1]).group(1)
      pw = re.search("ssh://(.*?):", b[2]).group(1)
      remark = re.search("ssh://(.*?):", b[3]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**     ◇⟨ SSH OpenVPN Account ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Username     :** `{remark}`
**» Password     :** `{pw}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» SSH UDP Account   :**
`{DOMAIN}:54-65535@{remark}:{pw}`
**» SSH WSS Account  :**
`{DOMAIN}:80@{remark}:{pw}`
**◇━━━━━━━━━━━━━━━━━━━━━◇** 
**» Limit Adress        :** `{ip} IP`
**» Host Domain       :** `{DOMAIN}`
**» Host NSDomain  :** `{ns}`
**» Pub Key               :** `{pub}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Port UDP Custom    :** `54-65535` 
**» Port SSL TLS/SNI    :** `443` 
**» Port WSS NTLS        :** `80, 8080, 8880`
**» Port WSS TLS/SNI   :** `443`
**» Port OVPN                :** `443, 1194, 2200`
**» Proxy Squid              :** `3128`
**» BadVPN UDP            :** `7100-7300`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» OpenVPN Config  :**
**https://{DOMAIN}:81/OpenVPN.zip**
**» Psiphon Config    :**
**https://{DOMAIN}:81/psiphon.txt**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account       :**
**https://{DOMAIN}:81/ssh-{remark}.txt**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `1 Day`
**» 🤖@ownerimmanvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
##      cmd2 = f'/usr/sbin/triall ssh {remark} | at now +15 minutes'
##      subprocess.run(cmd2, shell=True, executable="/bin/bash")
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await trial_ssh_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

#CEK SSH
@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def cek_ssh(event):
  async def cek_ssh_(event):
    cmd = '/etc/shell/cek ssh'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**   ◇⟨ List SSH OpenVPN Account ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
{z}
**» 🤖@ownerimmanvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_ssh_(event)
  else:
    await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
  async def login_ssh_(event):
    cmd = '/etc/shell/loginx ssh'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""

{z}
**» 🤖@ownerimmanvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await login_ssh_(event)
  else:
    await event.answer("Access Denied",alert=True) 

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
  async def delete_ssh_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    await event.edit("`Processing Deleted Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" | /etc/shell/del ssh'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇⟨ Succes Delete SSH Account ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» 🤖@ownerimmanvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_ssh_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def ren_ssh(event):
  async def ren_ssh_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Date**",buttons=[
[Button.inline("• 7 Days •","7"),
Button.inline("• 15 Days •","15")],
[Button.inline("• 30 Days •","30"),
Button.inline("• 60 Days •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Update Premium Account`")
    await asyncio.sleep(1)

    for i in range(101):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 6) + "▱" * ((100 - i) // 6)
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" | /etc/shell/ren ssh'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      x = [x.group() for x in re.finditer("exp://(.*)",a)]
      print(x)
      exp1 = re.search("exp://(.*?)@",x[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇⟨ Succes Renew SSH Account ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» IP :** `{ip}`
**» Expired On :** `{exp1}`
**» 🤖@ownerimmanvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_ssh_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)
    
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
  async def ssh_(event):
    inline = [
[Button.inline("[ Create SSH ]","create-ssh"),
Button.inline("[ Triall SSH ]","trial-ssh")],
[Button.inline("[ Delete SSH ]","delete-ssh"),
Button.inline("[ Renew SSH ]","renew-ssh")],
[Button.inline("[ Check SSH ]","cek-ssh"),
Button.inline("[ Login SSH ]","login-ssh")],
[Button.inline("‹ Main Menu ›","menu")]]
    z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**    ◇⟨ SSH OpenVPN MANAGER ⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Service   :** `SSH, UDP`
**» Service   :** `OpenVPN`
**» Service   :** `SlowDNS`
**» Service   :** `Psiphon`
**» Domain   :** `{DOMAIN}`
**» ISP VPS  :** `{z["isp"]}`
**» Country  :** `{z["country"]}`
**» 🤖@ownerimmanvpn**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ssh_(event)
  else:
    await event.answer("Access Denied",alert=True)
